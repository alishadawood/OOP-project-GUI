package airlinerproject;

public class Customer extends Person {
    private String passportNo;
    private String nationalID;
    private String address;
    private String contact;
    private String gender;
    private String dateOfBirth;

    public Customer(String id, String firstName, String lastName, String passportNo, String nationalID,
                    String address, String contact, String gender, String dateOfBirth) {
        super(id, firstName, lastName); // Call the constructor of Person
        this.passportNo = passportNo;
        this.nationalID = nationalID;
        this.address = address;
        this.contact = contact;
        this.gender = gender;
        this.dateOfBirth = dateOfBirth;
    }

    public String getPassportNo() {
        return passportNo;
    }

    public void setPassportNo(String passportNo) {
        this.passportNo = passportNo;
    }

    public String getNationalID() {
        return nationalID;
    }

    public void setNationalID(String nationalID) {
        this.nationalID = nationalID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    @Override
    public String toFileFormat() {
        return "Customer ID: " + id +
               ", First Name: " + firstName +
               ", Last Name: " + lastName +
               ", Passport No: " + passportNo +
               ", National ID: " + nationalID +
               ", Address: " + address +
               ", Contact: " + contact +
               ", Gender: " + gender +
               ", Date of Birth: " + dateOfBirth;
    }
}
