/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airlinerproject.FileHandling;

import java.io.*;
import java.util.Scanner;

public class FlightReservationSystem {
    private static final String FLIGHT_FILE_PATH = "flights.txt";

    public static void displayFlights() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FLIGHT_FILE_PATH))) {
            System.out.println("Available Flights:");
            System.out.println("------------------");
            String line;
            while ((line = reader.readLine()) != null) {
                String[] flight = line.split(",");
                System.out.println("Flight ID: " + flight[0]);
                System.out.println("Source: " + flight[1]);
                System.out.println("Destination: " + flight[2]);
                System.out.println("Departure Time: " + flight[3]);
                System.out.println("Seats Available: " + flight[4]);
                System.out.println("------------------");
            }
        } catch (IOException e) {
            System.out.println("No flights available.");
        }
    }

    public static void reserveFlight() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FLIGHT_FILE_PATH))) {
            BufferedReader userInputReader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the Flight ID: ");
            String flightId = userInputReader.readLine();

            String line;
            StringBuilder fileContent = new StringBuilder();
            boolean flightFound = false;

            while ((line = reader.readLine()) != null) {
                String[] flight = line.split(",");
                if (flight[0].equals(flightId)) {
                    int seatsAvailable = Integer.parseInt(flight[4]);
                    if (seatsAvailable > 0) {
                        flight[4] = String.valueOf(seatsAvailable - 1);
                        flightFound = true;
                    } else {
                        System.out.println("No seats available for the selected flight.");
                    }
                }
                fileContent.append(String.join(",", flight)).append(System.lineSeparator());
            }

            if (!flightFound) {
                System.out.println("Flight ID not found.");
            } else {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(FLIGHT_FILE_PATH))) {
                    writer.write(fileContent.toString());
                    System.out.println("Flight reserved successfully.");
                } catch (IOException e) {
                    System.out.println("Error updating flight reservation.");
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading flight data.");
        }
    }

    public static void addFlight() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FLIGHT_FILE_PATH, true))) {
            Scanner userInput = new Scanner(System.in);

            System.out.print("Enter the Flight ID: ");
            String flightId = userInput.nextLine();
            System.out.print("Enter the Source: ");
            String source = userInput.nextLine();
            System.out.print("Enter the Destination: ");
            String destination = userInput.nextLine();
            System.out.print("Enter the Departure Time: ");
            String departureTime = userInput.nextLine();
            System.out.print("Enter the Seats Available: ");
            String seatsAvailable = userInput.nextLine();

            String newFlight = flightId + "," + source + "," + destination + "," + departureTime + "," + seatsAvailable;
            writer.write(newFlight);
            writer.newLine();
            System.out.println("Flight added successfully.");
        } catch (IOException e) {
            System.out.println("Error adding flight.");
        }
    }

    public static void deleteFlight() {
        try (BufferedReader reader = new BufferedReader(new FileReader(FLIGHT_FILE_PATH))) {
            BufferedReader userInputReader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Enter the Flight ID to delete: ");
            String flightId = userInputReader.readLine();

            String line;
            StringBuilder fileContent = new StringBuilder();
            boolean flightFound = false;

            while ((line = reader.readLine()) != null) {
                String[] flight = line.split(",");
                if (flight[0].equals(flightId)) {
                    flightFound = true;
                    continue; // Skip deleting this line from the file
                }
                fileContent.append(String.join(",", flight)).append(System.lineSeparator());
            }

            if (!flightFound) {
                System.out.println("Flight ID not found.");
            } else {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(FLIGHT_FILE_PATH))) {
                    writer.write(fileContent.toString());
                    System.out.println("Flight deleted successfully.");
                } catch (IOException e) {
                    System.out.println("Error deleting flight.");
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading flight data.");
        }
    }

    public static void main(String[] args) {
        Scanner userInput = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Flight Reservation System Menu:");
            System.out.println("1. Display Flights");
            System.out.println("2. Reserve Flight");
            System.out.println("3. Add Flight");
            System.out.println("4. Delete Flight");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = userInput.nextInt();

            switch (choice) {
                case 1:
                    displayFlights();
                    break;
                case 2:
                    reserveFlight();
                    break;
                case 3:
                    addFlight();
                    break;
                case 4:
                    deleteFlight();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }
}