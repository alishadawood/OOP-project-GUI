/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package airlinerproject;

public class Flight {
        private String flightNo;
        private String customerId;
        private String firstName;
        private String lastName;
        private String departure;
        private String duration;
        private String dateOfFlight;
        private String seats;
        private String fare;

        public Flight(String flightNo, String customerId, String firstName, String lastName, String departure, 
                      String duration, String dateOfFlight, String seats, String fare) {
            this.flightNo = flightNo;
            this.customerId = customerId;
            this.firstName = firstName;
            this.lastName = lastName;
            this.departure = departure;
            this.duration = duration;
            this.dateOfFlight = dateOfFlight;
            this.seats = seats;
            this.fare = fare;
        }

        // Format flight data for writing to file
        public String toFileFormat() {
            return "Flight No: " + flightNo +
                   ", Customer ID: " + customerId +
                   ", First Name: " + firstName +
                   ", Last Name: " + lastName +
                   ", Departure: " + departure +
                   ", Duration: " + duration +
                   ", Date of Flight: " + dateOfFlight +
                   ", Seats: " + seats +
                   ", Fare: " + fare;
        }
    }